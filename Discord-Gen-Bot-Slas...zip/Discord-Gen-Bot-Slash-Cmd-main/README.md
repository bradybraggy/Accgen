![img](https://cdn.discordapp.com/avatars/1002860202535682058/7c4a08eabe25cb095c6e89677469f457.png?size=512)

## 💥 About
Discord Gen Bot 
This Bot Help You To Give Accounts In Your Discord Server Slash Cmd Support
Made By ScienceGear#4409




## 🕳 Cmds
**/gen or /generate**
It Is Use To Gen Account In Your Dm

**/stock**
Use To See How May Stock Are Left Over

**/help**
For Help And Cmds

**/change (Admin Only)**
Chanege Cooldown Or ID Of Channel

**/add**
Add Accounts In Your Bot

